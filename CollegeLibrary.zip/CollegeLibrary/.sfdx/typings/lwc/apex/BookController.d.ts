declare module "@salesforce/apex/BookController.getBooks" {
  export default function getBooks(): Promise<any>;
}
declare module "@salesforce/apex/BookController.getBook" {
  export default function getBook(param: {bookId: any}): Promise<any>;
}
