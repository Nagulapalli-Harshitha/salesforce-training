import { LightningElement, api, wire } from 'lwc';
import getBook from '@salesforce/apex/BookController.getBook';

export default class BookChild extends LightningElement {

    @api bookId;

    book;

    @wire(getBook, { bookId: '$bookId' })
    wiredBook({ data, error }) {

        console.log('Book Id =', this.bookId);

        if (data) {
            console.log('Book received', data);
            this.book = data;
        }

        if (error) {
            console.error(JSON.stringify(error));
        }
    }

    notifyParent() {
        this.dispatchEvent(
            new CustomEvent('notifyparent', {
                detail: 'Button clicked in Child Component'
            })
        );
    }
}