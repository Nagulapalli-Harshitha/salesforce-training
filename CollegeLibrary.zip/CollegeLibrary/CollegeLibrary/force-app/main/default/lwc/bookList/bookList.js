import { LightningElement, wire } from 'lwc';
import getBooks from '@salesforce/apex/BookController.getBooks';

const columns = [
    { label: 'Book Name', fieldName: 'Name' },
    { label: 'Author', fieldName: 'Author__c' },
    { label: 'Category', fieldName: 'Category__c' },
    { label: 'Available Copies', fieldName: 'Available_Copies__c', type: 'number' }
];

export default class BookList extends LightningElement {

    books;
    columns = columns;

    @wire(getBooks)
    wiredBooks({ error, data }) {
        if (data) {
            this.books = data;
        } else if (error) {
            console.error(error);
        }
    }
}