import { LightningElement } from 'lwc';

export default class BookParent extends LightningElement {

    bookId = '';

    message = 'Waiting for Child';

    handleChange(event) {

        this.bookId = event.target.value;

        console.log('Book Id = ' + this.bookId);

    }

    handleNotify(event) {

        this.message = event.detail;

    }

}