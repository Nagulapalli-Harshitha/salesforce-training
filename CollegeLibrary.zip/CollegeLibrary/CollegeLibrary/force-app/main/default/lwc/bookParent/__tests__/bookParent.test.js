<template>

    <lightning-card title="Parent Component">

        <div class="slds-p-around_medium">

            <lightning-input
                label="Enter Book Record Id"
                value={bookId}
                onchange={handleChange}>
            </lightning-input>

            <br/>

            <p>
                <b>Message:</b> {message}
            </p>

            <br/>

            <c-book-child
                book-id={bookId}
                onnotifyparent={handleNotify}>
            </c-book-child>

        </div>

    </lightning-card>

</template>